// import express from 'express';
// const app = express();
// app.get('/', (req, res) => {
//   res.send('Hello World from Express in Docker!');
// });
// app.listen(3000, () => {
//   console.log('Server is running on port 3000');
// });
// ---------------Html File --------------------
import express from 'express';
import path from 'node:path';

// 1. Initialize the app (THIS WAS MISSING)
const app = express(); 

// 2. Setup static files folder
app.use(express.static('public'));

// 3. Define the route
app.get('/', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'public', 'index.html'));
});

// 4. Start the server
app.listen(4000, () => {
    console.log('Server is running on http://localhost:4000');
});